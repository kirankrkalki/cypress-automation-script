describe('testcase', () => {
    context(`Generating a test case`, () => {
        it('Navigate to url and login.', () => {
            //Navigating to url 
            cy.visit('https://consignment.intutrack.com/#/')
            cy.get('#login3').type("test1")
            cy.get('#login4').type("test1")
            cy.get('#login2').click()
            cy.wait(5000)
            cy.get('#home1').click()
            cy.get('#home20').type('Gati')
            cy.get('#home7 > .layout > :nth-child(1) > .v-input > .v-input__control > .v-input__slot > .v-select__slot > :nth-child(4) > .v-input__icon > .v-icon').click()
            cy.get('#home21').type('9998222666')
            cy.get(':nth-child(3) > .v-input > .v-input__control > .v-input__slot > .v-text-field__slot > #home30').type('69741112333')
            cy.get('#home22').type('2441')
            
            cy.get('#home23').type('Bengaluru')
            cy.get('#home24').type('workflow')
            cy.wait(3000)
            cy.get('#home25').click()
            cy.get(':nth-child(4) > :nth-child(4) > .v-btn > .v-btn__content').click()
            cy.get('#home29').click()
            cy.get(':nth-child(8) > .v-input > .v-input__control > .v-input__slot > .v-text-field__slot > #home30').type('1')
            cy.get('#home7 > .layout > :nth-child(1) > .v-input > .v-input__control > .v-input__slot > .v-select__slot > :nth-child(4) > .v-input__icon > .v-icon').click()
            cy.get(':nth-child(1) > .v-list__tile > #drop3 > #drop5').click()
            cy.get('#home9 > .v-btn__content').click()
        })
    })
})

